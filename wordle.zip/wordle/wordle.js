let intentos =6;
let lista = ["RATON", "NADIE", "MONTO", "PIEZA", "CINCO", "MENTA"];

//console.log("elementos",lista.length);
//console.log("random",Math.floor(Math.random()* lista.length));

let posicion= Math.floor(Math.random()* lista.length)
let palabra= lista[posicion];

window.addEventListener('load',init);
const INPUT = document.getElementById('guess-input');
const BOTON = document.getElementById('guess-button');

function init(){
    console.log('Esto se ejecuta solo cuando se carga la pagina web')
}
const button = document.getElementById("guess-button");


    function leerIntento(){
       return INPUT.value.toUpperCase();
    }
function intentar(){
    const INTENTO = leerIntento();
    const GRID = document.getElementById("grid");
    const ROW= document.createElement("div");
    ROW.className="Row";
    console.log('div', ROW);

    for (let i in palabra){
        const SPAN = document.createElement("span");
        SPAN.className= "letter";
        console.log(SPAN);
        SPAN.innerHTML = INTENTO[i];
        if (INTENTO[i]===palabra[i]){
            console.log(INTENTO[i], "VERDE");
            SPAN.style.backgroundColor= "green";
        }else if (palabra.includes(INTENTO[i])){
            console.log(INTENTO[i], "AMARILLO");
            SPAN.style.backgroundColor= "yellow";
        } else{
            console.log(INTENTO[i],"GRIS");
            SPAN.style.backgroundColor= "gray";
        } 
        ROW.appendChild(SPAN);
    }
    GRID.appendChild(ROW);
    if(INTENTO === palabra){
        terminar("<h1>GANASTE!</h1>");
        return;
    } 
    
    
    intentos=intentos-1;
    console.log("Te quedan", intentos, "intentos.");

    if (intentos==0){
        terminar("<h1>¡PERDISTE!</h1>");
     }

}


   

function terminar(mensaje){
    const INPUT = document.getElementById('guess-input');
    const BOTON = document.getElementById('guess-button');
    INPUT.disabled= true;
    BOTON.disabled= true;
    let contenedor= document.getElementById('guesses');
    contenedor.innerHTML= mensaje;
}




button.addEventListener("click", intentar);
